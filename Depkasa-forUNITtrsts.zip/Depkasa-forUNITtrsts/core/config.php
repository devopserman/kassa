<?php

defined( 'BASEPATH' ) OR exit( 'No direct script access allowed' );

$config = [
    'apiKey'           => 'daef4ff758859227ac5ff22b3d73e090',
    'secretKey'        => 'f07fce0a',
    'paymentURL'       => 'https://mock01.ecpdss.net/depkasa/a/payment/welcome',
    'paymentDetailURL' => 'https://mock01.ecpdss.net/depkasa/a/payment/detail',
    'database'         => [
        'drv'    => 'mysql',
        'host'   => '',
        'dbname' => 'depkasa',
        'user'   => '',
        'pass'   => ''
    ],
];
